import Layout from "../../components/Layout/index.js";
import Sidebar from "../../components/sidebar/sidebar";

const Dashboard = () => {

  return <Layout>
      <Sidebar/>
  </Layout>;
};

export default Dashboard;
