export const snackbarSelector = (state) => state.common.snackbar;
